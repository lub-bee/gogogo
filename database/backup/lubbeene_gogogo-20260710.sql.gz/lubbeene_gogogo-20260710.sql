-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: lubbeene_gogogo
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_at` datetime(5) NOT NULL,
  `end_at` datetime(5) DEFAULT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci,
  `description_ja` text COLLATE utf8mb4_unicode_ci,
  `published_at` date DEFAULT NULL,
  `cost` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `topic_id` bigint unsigned DEFAULT NULL,
  `location_id` bigint unsigned DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `events_slug_unique` (`slug`),
  KEY `events_user_id_foreign` (`user_id`),
  KEY `events_topic_id_foreign` (`topic_id`),
  KEY `events_location_id_foreign` (`location_id`),
  CONSTRAINT `events_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `events_topic_id_foreign` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE SET NULL,
  CONSTRAINT `events_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'2024 Hirosegawa Imonikai','2024-02-01 12:00:00.00000','2024-02-01 14:00:00.00000','<h1>the first GoGoGo Imonikai!</h1><p><br></p><p>Our first, certainly, but not the least!</p><p>Let\'s cook some <strong>meet</strong>, <strong>veggies</strong>, <strong>fish</strong>, <strong>mocchi</strong> and some more!</p><p><br></p><p><em>Reach us in case of allergy, or bring something you are safe to eat</em></p><p>And let\'s have a tons of fun.</p>','<h1>初めての GoGoGo 芋煮会！</h1><p><br></p><p>初めての開催ですが、絶対に特別なイベントです！</p><p>お肉、野菜、魚、餅など、いろいろなものを料理しましょう！</p><p><br></p><p><em>アレルギーがある場合はご連絡いただくか、安全に食べられるものをお持ちください。</em></p><p>たくさん楽しみましょう！</p>','2024-09-03',NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',1,1,1,'2024-hirosegawa-imonikai'),(2,'Adipisci et temporibus consequatur quia corporis.','1977-06-23 13:39:58.00000',NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',4,3,4,'sunt-corporis-voluptas-eaque-aut-deserunt'),(3,'Est deleniti laudantium ex est debitis et et.','1973-06-19 07:01:39.00000',NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',3,3,2,'laborum-quis-et-natus-magni-possimus'),(4,'Aut dolorem aut cupiditate possimus rem magni voluptatem.','1991-09-06 12:39:09.00000',NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',5,3,2,'sunt-cumque-deleniti-consequatur-nam-aut-nihil'),(5,'Qui cumque et tempore cum eum.','1978-02-10 00:39:48.00000',NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',3,3,5,'ab-vel-voluptates-eos-fuga-nemo'),(6,'Esse eligendi eligendi tempore reprehenderit pariatur est rerum.','2003-08-14 21:55:07.00000',NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',8,3,1,'odio-laborum-quia-ad-sit');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci,
  `description_ja` text COLLATE utf8mb4_unicode_ci,
  `gps_long` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gps_lat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `locations_slug_unique` (`slug`),
  KEY `locations_user_id_foreign` (`user_id`),
  CONSTRAINT `locations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Hirosegawa BBQ Square','Hirosegawa BBQ Square',NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',1,'hirosegawa-bbq-square'),(2,'Veniam et corporis cupiditate earum.',NULL,NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',1,'nesciunt-illum-dolorem-corrupti'),(3,'Aspernatur qui nulla in expedita.',NULL,NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',1,'vel-non-adipisci-ducimus-ab-quis-illum-et-itaque'),(4,'Unde ea vero quis.',NULL,NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',3,'enim-maiores-ipsam-expedita-odio'),(5,'Est porro et qui eos voluptas.',NULL,NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',3,'ullam-veritatis-libero-perferendis-magni-non-perspiciatis'),(6,'Illum voluptatem aliquam.',NULL,NULL,NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',9,'ea-maiores-sed-enim-placeat');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medias`
--

DROP TABLE IF EXISTS `medias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medias` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `validated_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `event_id` bigint unsigned DEFAULT NULL,
  `legend` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `medias_user_id_foreign` (`user_id`),
  KEY `medias_event_id_foreign` (`event_id`),
  CONSTRAINT `medias_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medias_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medias`
--

LOCK TABLES `medias` WRITE;
/*!40000 ALTER TABLE `medias` DISABLE KEYS */;
INSERT INTO `medias` VALUES (1,'Sapiente architecto vitae aut commodi rem.',NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',7,NULL,NULL),(2,'Qui ea voluptate.',NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',5,NULL,NULL),(3,'Iusto porro sequi.',NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',8,NULL,NULL),(4,'Facere quo dolore sapiente eveniet aspernatur.',NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',3,NULL,NULL),(5,'Nihil aspernatur eum in ipsum excepturi.',NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',5,NULL,NULL);
/*!40000 ALTER TABLE `medias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_12_19_044147_create_locations_table',1),(6,'2023_12_19_121847_create_topics_table',1),(7,'2023_12_20_104253_create_events_table',1),(8,'2023_12_26_044201_create_medias_table',1),(9,'2023_12_26_044250_create_tags_table',1),(10,'2024_04_19_045210_remove_media_description',1),(11,'2024_07_04_111358_create_events_slugs',1),(12,'2024_07_30_123800_create_topics_slugs',1),(13,'2024_07_30_123836_create_locations_slugs',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci,
  `description_ja` text COLLATE utf8mb4_unicode_ci,
  `published_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `topics_slug_unique` (`slug`),
  KEY `topics_user_id_foreign` (`user_id`),
  CONSTRAINT `topics_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
INSERT INTO `topics` VALUES (1,'What is your recipe?',NULL,'What is your recipe?','これのレシピは何ですか？',NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',5,'hirosegawa-imonikai'),(2,'Cupiditate eius eum vitae exercitationem.',NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',8,'pariatur-accusamus-nobis-officia-qui-aliquid-qui-dolor-excepturi'),(3,'Nesciunt veniam nisi.',NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',8,'quidem-in-quis-amet-veritatis-sequi-ipsum-et'),(4,'Molestiae suscipit est vero.',NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',7,'iusto-consectetur-rem-incidunt-sit-mollitia-sint-et'),(5,'Tenetur et cupiditate.',NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',5,'fuga-vel-numquam-iusto-qui-suscipit'),(6,'Odit dolores.',NULL,NULL,NULL,NULL,'2024-09-03 15:25:32','2024-09-03 15:25:32',8,'vero-eaque-itaque-unde-atque-perspiciatis-dignissimos-voluptate');
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rank` enum('admin','support','visitor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'visitor' COMMENT 'Admin : 100, Support : 10, Visitor : 0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Mahul','mahul@patel.com','2024-09-03 15:25:31','$2y$12$ncMdSz2PReBifhTiSYnb6e9aeyYsEP5jMSNeZ7EZx9845HpCVBl9a','admin','dgxZWEbQXo','2024-09-03 15:25:31','2024-09-03 15:25:31'),(2,'Ludo','brient@tikyus.co.jp','2024-09-03 15:25:31','$2y$12$HxyMiFPXCra69vsnsIQosOjwUXcuEN53HwO6iJw7VEuINcjvqnoSa','admin','joZfEr8o94','2024-09-03 15:25:31','2024-09-03 15:25:31'),(3,'Admin','admin@mail.com','2024-09-03 15:25:31','$2y$12$lglcdDkE3Suc085hxFm7Wedk4bjgqccg6W0j6TpsxPKjYoirtvaMi','admin','FkAVA2AYPL','2024-09-03 15:25:31','2024-09-03 15:25:31'),(4,'Support','support@mail.com','2024-09-03 15:25:31','$2y$12$TF0Ja.JJTGfQ3HPVe8smtenQX/GHzabgPnUPQ6tiyPBnk8z/LatgW','support','nV6RmkNIpw','2024-09-03 15:25:32','2024-09-03 15:25:32'),(5,'Visitor','visitor@mail.com','2024-09-03 15:25:32','$2y$12$Ly46HHYGfiIy3Pzx2j..XeDw.j2drH/PvZ29RGg6alprSSPka3nei','visitor','dcaxDpk06b','2024-09-03 15:25:32','2024-09-03 15:25:32'),(6,'Bernardo Paucek','charlie.fisher@example.org','2024-09-03 15:25:32','$2y$12$0Q5vDlKy0v.e2TM85YWDKOUD2QxUalVJIz8CSD.Hp19/uUgMB/oii','visitor','OTxl9m4bYB','2024-09-03 15:25:32','2024-09-03 15:25:32'),(7,'Prof. Fletcher Hayes','anderson.dewayne@example.com','2024-09-03 15:25:32','$2y$12$0Q5vDlKy0v.e2TM85YWDKOUD2QxUalVJIz8CSD.Hp19/uUgMB/oii','visitor','S2Y1KTzBgs','2024-09-03 15:25:32','2024-09-03 15:25:32'),(8,'Hugh Bernier III','boyle.consuelo@example.org','2024-09-03 15:25:32','$2y$12$0Q5vDlKy0v.e2TM85YWDKOUD2QxUalVJIz8CSD.Hp19/uUgMB/oii','visitor','b7KLggHLHQ','2024-09-03 15:25:32','2024-09-03 15:25:32'),(9,'Oral Stanton','pfay@example.net','2024-09-03 15:25:32','$2y$12$0Q5vDlKy0v.e2TM85YWDKOUD2QxUalVJIz8CSD.Hp19/uUgMB/oii','visitor','u46oQizcsW','2024-09-03 15:25:32','2024-09-03 15:25:32'),(10,'Dr. Jackson Bashirian','rcassin@example.com','2024-09-03 15:25:32','$2y$12$0Q5vDlKy0v.e2TM85YWDKOUD2QxUalVJIz8CSD.Hp19/uUgMB/oii','visitor','DPRsuPdmYq','2024-09-03 15:25:32','2024-09-03 15:25:32');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-10 16:48:53
